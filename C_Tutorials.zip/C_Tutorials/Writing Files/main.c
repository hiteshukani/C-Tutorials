#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Two types of files: Sequential Access File and Random Access File
    FILE * fPointer;
    fPointer = fopen("info.txt", "w");      // "w" is used to write in new text file, "r" is used to read and "a" is used to add text in existing file

    fprintf(fPointer, "Pizza is good\n");

    fclose(fPointer);                       // close the file after use

    return 0;
}
