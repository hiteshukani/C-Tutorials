#include <stdio.h>
#include <stdlib.h>

int main()
{
    int age;
    char gender;

    printf("How old are you? \n");
    scanf(" %d", &age);                     // Always use space in " %d" as a good programmer it depends on compiler

    printf("What is your gender? (m/f) \n");
    scanf(" %c", &gender);                  // Always use space in " %c" as a good programmer it depends on compiler


    if(age >= 18)                           // if(condition) if the condition is true and satisfied the code under this block is executed
    {
        printf("Welcome to the Party \n");

        if(gender == 'm')                   // Always use (==) sign to equate in IF Condition
        {
            printf("Party Hard Guys...!!!");
        }
        if(gender == 'f')                   // Always use (==) sign to equate in IF Condition
        {
            printf("BEWARE of Dicks!!! LOL...!!!");
        }
    }
    if(age < 18)
    {
        printf("Grow up baby...!!! \n");
    }
    return 0;
}
