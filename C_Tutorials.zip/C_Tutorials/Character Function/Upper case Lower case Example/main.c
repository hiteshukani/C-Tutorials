#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>                          // This .h file provides bunch of built in character
#include <string.h>
#include <math.h>

int main()
{
    int a = 'v';

    if(isalpha(a))                                          // isalpha function check whether the given character is alphabet
    {
        if(isupper(a))                                      // isupper function check whether the given character is upper case alphabet
        {
            printf("%c is a Upper Case Alphabet \n", a);
        }
        else
        {
            printf("%c is a Lower Case Alphabet \n", a);
            printf("%c \n", toupper(a));                    // toupper function converts the given lower case character to upper case character
        }
    }
    else
    {
        if(isdigit(a))                                      // isdigit function check whether the given character is digit
        {
            printf("%c is a Digit \n", a);
        }
        else
        {
            printf("WTF... %c is a Special Character", a);
        }
    }
    return 0;
}
