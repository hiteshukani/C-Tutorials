#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>                          // This .h file provides bunch of built in character
#include <string.h>
#include <math.h>

int main()
{
    int a = 'H';

    if(isalpha(a))
    {
        printf("%c is a Alphabet \n", a);
    }
    else
    {
        if(isdigit(a))
        {
            printf("%c is a Digit \n", a);
        }
        else
        {
            printf("WTF... %c is a Special Character", a);
        }
    }
    return 0;
}
