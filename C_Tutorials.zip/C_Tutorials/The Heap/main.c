#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Heap is extra memory that you can borrow from your system
    int * points;

    points = (int *) malloc(4 * sizeof(int));           // malloc(howMuchMemory) is function used to borrow i.e to get memory from system;
                                                        // use (float *) in case you use float, here we use int so we use (int *) is int typecast pointer
    free(points);                                       // free(name of function for which you are usin Heap) is used to give back memory back to system



    return 0;
}
