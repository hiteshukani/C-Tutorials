#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    char grade = 'A';

    switch(grade)
    {
        case 'A': printf("Excellent!!! Keep it up \n");
                  break;
        case 'B': printf("Good, but try to get better \n");
                  break;
        case 'C': printf("Work Harder \n");
                  break;
        case 'F': printf("It was embarrassing \n");
                  break;
        default : printf("It doesn't make any sense \n");
    }
    return 0;
}
