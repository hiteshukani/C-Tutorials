#include <stdio.h>
#include <stdlib.h>

int main()
{
    float avgProfit;
    int priceOfNuts = 12;
    int sales = 150;
    int numberOfDays = 7;

    avgProfit = ( (float)priceOfNuts * (float)sales) / (float)numberOfDays;     // (float) before variables converts them into float temporary
    printf("Average Profit per days: $%.2f \n", avgProfit);                     // %.2f takes the value upto 2 decimal points
    return 0;
}
