#include <stdio.h>
#include <stdlib.h>

int main()
{
    char Name[7] = "Hitesh";            // Defining size of Array manually
    printf("My name is %s \n", Name);

    Name[0] = 'R';                      // Assigning a value to specific element of Array
    printf("My name is %s \n", Name);

    char Food[] = "Pizza";              // Automatic define size of Array
    printf("My Favorite food is %s \n", Food);

    strcpy(Food, "Maggi");              // String Copy Operator: Changes the value of string defined in function
    printf("My Favorite food is %s \n", Food);
    return 0;
}
