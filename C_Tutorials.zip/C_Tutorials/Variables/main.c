#include <stdio.h>
#include <stdlib.h>

int main()
{
    int age;
    int currentYear;
    int birthYear;

    currentYear = 2015;
    birthYear = 1993;
    age = currentYear - birthYear;

    printf("Hitesh is %d years old\n", age);
    return 0;
}
