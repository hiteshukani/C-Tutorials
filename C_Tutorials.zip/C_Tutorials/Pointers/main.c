#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int pizza = 21;

    printf("Address \t Name \t Value \n");

    // printf("%p \t %s \t %d \n", &pizza, "pizza", pizza);        // ("%p ", &variable_name); gives the memory address of variable

    int * pPizza = &pizza;                                      // pPizza is storing pointer of Pizza NOTE: * is used as pointer to define memory address

    printf("%p \t %s \t %d \n", pPizza, "pizza", pizza);

    printf("%p \t %s \t %p \n", &pPizza, "pPizza", pPizza);

    return 0;
}
