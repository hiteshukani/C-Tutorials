#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 7, b = 10, ans;
    // add 1 to a before equation execute i.e. pre-increment
    ans = ++a * b;
    printf("Answer: %d \n", ans);

    a = 7, b = 10, ans;
    ans = a++ * b;
    // add 1 to a after equation is executed i.e. post-increment
    printf("Answer: %d \n", ans);

    return 0;
}
