#include <stdio.h>
#include <stdlib.h>

/* This Program prints my name and
address */

int main()
{

    // This are the instructions to print

    printf("I'm Hitesh Ukani\n");   // \n for new line
    printf("Gannon University\t");  // \t for inserting tab
    printf("PA-USA\a");             // \a for beep
    return 0;
}
