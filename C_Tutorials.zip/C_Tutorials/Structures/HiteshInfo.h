struct students             // syntax to define structure
{
    int userID;
    char firstName[10];
    char lastName[10];
    int age;
    float weight;
}
;
