#include <stdio.h>
#include <stdlib.h>
#include "HiteshInfo.h"

int main()
{
    // In structure is an type of array in which you can store int, char, float and all
    struct students Hitesh;
    struct students Shubham;

    Hitesh.userID = 63;                     // format to access structure data
    Shubham.userID = 61;

    puts("Enter the first name of user 1");
    gets(Hitesh.firstName);

    puts("Enter the first name of user 2");
    gets(Shubham.firstName);

    printf("User 1 ID is %d\n", Hitesh.userID);
    printf("User 2 first name is %s\n", Shubham.firstName);

    return 0;
}
