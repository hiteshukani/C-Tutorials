#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("I'm Hitesh Ukani\n");
    printf("Gannon University\t");
    printf("PA-USA\a");
    return 0;
}
