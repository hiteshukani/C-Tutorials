#include <stdio.h>
#include <stdlib.h>

int main()
{
    int studyHours;    // Ideal value >= 10
    int fights;         // Ideal value == 0

    printf("Enter the hours student studies: \n");
    scanf(" %d", &studyHours);
    printf("Enter No. of Fights: \n");
    scanf(" %d", &fights);

    if( (studyHours >= 10) && (fights == 0) )       // if ((test1) && (test2)) NOTE: 0 0 = 0, 0 1 = 0, 1 0 = 0, 1 1 = 1. Hint: Keep test1 whose chance of failing is higher
    {
        printf("You are a Good Student");
    }
    else
        printf("You are Dumb");
    return 0;
}
