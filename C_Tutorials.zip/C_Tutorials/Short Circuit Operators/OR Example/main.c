#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ans;

    printf("Do you like Pizza? (y/n) \n");      // Case Sensitive
    scanf(" %c", &ans);

    if ( (ans == 'y') || (ans == 'n') )         // OR Operator: 0 0 = 0, 0 1 = 1, 1 0 = 1, 1 1 = 1
    {
        printf("Thank you... \n");
    }
    else
        {
            printf("Kehboard Much...!!! \n");
        }
    return 0;
}
