#include <stdio.h>
#include <stdlib.h>

int main()
{
    int friends;

    printf("Enter No. of Friends: \n");
    scanf(" %d", &friends);

    printf("I have %d friend%s", friends, (friends!=1) ? "s" : "");       // %s place s for Friends is !=1
    return 0;
}
