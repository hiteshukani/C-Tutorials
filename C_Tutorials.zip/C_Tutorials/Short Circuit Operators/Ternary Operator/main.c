#include <stdio.h>
#include <stdlib.h>

int main()
{
    char lastName[10];                      // Case sensitive
    printf("Enter your last name: \n");     // Must begin with Upper case
    scanf(" %s", lastName);                 // &lastName is not used because  it is array and %s for string

    (lastName [0] < 'M') ? printf("Red Team") : printf("Blue Team");        // (test) ? trueCode : falseCode; and lastName [0] for initial letter
    return 0;
}
