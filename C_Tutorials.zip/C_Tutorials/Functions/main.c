#include <stdio.h>
#include <stdlib.h>

void printSomething();               // Define function before calling it

int main()
{
    printSomething();               // Calling a function

    printSomething();

    return 0;
}


void printSomething()               // Creating a function
{
    printf("Hello I'm a function\n");
    return;
}
