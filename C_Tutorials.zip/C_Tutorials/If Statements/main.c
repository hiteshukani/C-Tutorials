#include <stdio.h>
#include <stdlib.h>

int main()
{
    int age;
    printf("How old are you? \n");
    scanf("%d", &age);

    if(age >= 18)                           // if(condition) if the condition is true and satisfied the code under this block is executed
    {
        printf("Welcome to the Party \n");
    }
    if(age < 18)
    {
        printf("Grow up baby...!!! \n");
    }
    return 0;
}
