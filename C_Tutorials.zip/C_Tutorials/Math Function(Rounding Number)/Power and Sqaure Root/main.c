#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>                               // This <math.h> provides different mathematical functions

int main()
{
    printf("Power is %.2f \n", pow(5, 3));      // This Function pow(base_value, exponent_value) gives power of this given values
    printf("Square Root is %.2f \n", sqrt(136));// This Function sqrt(Value) gives square root of given value

    return 0;
}
