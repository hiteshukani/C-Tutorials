#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>                               // This <math.h> provides different mathematical functions

int main()
{
    float weight1 = 67.741;
    float weight2 = 22.43;

    printf("Weight of First Person is %.2f \n", floor(weight1));    // This function floor(variable_name) rounds down to near whole number
    printf("Weight of Second Person is %.2f \n", floor(weight2));

    printf("Weight of First Person is %.2f \n", ceil(weight1));     // This function ceil(variable_name) rounds up to near whole number
    printf("Weight of Second Person is %.2f \n", ceil(weight2));

    return 0;
}
