#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int i;
    int choco[4] = {4, 7, 11, 8};

    for(i = 0; i < 4; i++)
    {
        printf("You are ate %d Chocolate on Day %d \n", choco[i], i+1);     // Day begins with 1 = (i + 1) as i starts with zero
    }

    int chocolate[5];
    int totalChoco = 0;
    i = 0;

    for(i = 0; i < 5; i++)
    {
        printf("\nHow may Chocolates did you ate on day %d? \n", i+1);
        scanf(" %d", &chocolate[i]);
    }

    for(i = 0; i < 5; i++)
    {
        totalChoco += chocolate[i];
    }

    int avg = totalChoco / 5;
    printf("You ate %d Chocolate Total, And %d Chocolate per Day! \n", totalChoco, avg);

    return 0;
}
