#include <stdio.h>
#include <stdlib.h>

int calBonus(int yearsWorked);

int main()
{
    int hiteshBonus = calBonus(14);         // 14 years = yearWorked
    int rahulBonus = calBonus(7);

    printf("Hitesh gets $%d bonus \n", hiteshBonus);
    printf("Rahul gets $%d bonus \n", rahulBonus);
    printf("Yash gets $%d bonus \n", calBonus(4));

    return 0;
}


int calBonus(int yearsWorked)
{
    int bonus = yearsWorked * 250;

    if(yearsWorked > 10)
    {
        bonus += 1000;
    }

    return bonus;
}
