#include <stdio.h>
#include <stdlib.h>

void printSomething();

int warts = 23;                     // Declaring Global Variable (Access to all scope of any function)

int main()
{
    printf("I have %d warts\n", warts);
    printSomething();
    return 0;
}


void printSomething()
{
    printf("Havig %d warts is not Bad!!!\n", warts);
    return;
}
