#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int i;
    int howMany;
    int maxAmount = 10;

    printf("How many times you want this loop to loop? (up to 10) \n");
    scanf(" %d", &howMany);

    if(howMany <=10)
    {

        for(i = 1; i <= maxAmount; i++)
        {
            printf("%d\n", i);

            if(i == howMany)
            {
                break;
            }
        }
    }
    else
        {
            printf("Invalid Input!!! ");
        }
    return 0;
}
