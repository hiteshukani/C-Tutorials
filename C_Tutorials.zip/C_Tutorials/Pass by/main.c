#include <stdio.h>
#include <stdlib.h>

void passByValue(int i);
void passByReference(int * i);

int main()
{
    int pizza = 21;
    passByValue(pizza);                                         // pizza = 20 i.e. pass a copy of variable pizza
    printf("Passing by Value, Pizza is now %d\n", pizza);

    passByReference(&pizza);                                    // (&pizza) it passes memory address of variable pizza
    printf("Passing by Reference, Pizza is now %d\n", pizza);
    return 0;
}


void passByValue(int i)
{
    i = 87;
    return;
}

void passByReference(int * i)
{
    * i = 63;
    return;
}
