#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int i;
    int balls[5] = {4, 7, 11, 21, 23};

    printf("Element \t Address \t Value \n");

    for(i = 0; i < 5; i++)
    {
        printf("balls[%d] \t %p \t %d \n", i, &balls[i], balls[i]);
    }

    // array names are just pointer to first element
    printf("\nballs \t\t %p \n", balls);                    // NOTE: for any array its basic name without any elements acts as pointer of first element so there is no (&balls) used

    //dereference it
    printf("\n*balls \t\t %d \n", *balls);

    printf("\n*(balls + 2) \t\t %d \n", *(balls + 2));

    return 0;
}
