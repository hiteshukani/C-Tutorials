#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int i;

    for(i = 1; i <= 10; i++)                // (Initial Value; Final Value; Operation)
        printf("No. of Pizza: %d \n", i);

    return 0;
}
