#include <stdio.h>
#include <stdlib.h>

int main()
{
    int day = 1;
    float amount = 0.01;

    while(day <= 31)                    // Format: while(condition) it continue to execute the code in while loop until its condition is false
    {
        printf("Day: %d \t Amount:$%.2f \n", day, amount);
        amount *= 2;
        day++;                          // NOTE: Always use increment operator in any loop to make it execute finite time
    }
    return 0;
}
