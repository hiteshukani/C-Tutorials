#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int rows;
    int columns;

    for(rows = 1; rows <= 5; rows++)
    {
        for(columns = 1; columns <= 5; columns++)
        {
            printf("%d ", columns);
        }
        printf("\n");
    }
    return 0;
}
