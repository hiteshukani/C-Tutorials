#include <stdio.h>
#include <stdlib.h>

int main()
{
    float grade = 0;
    float score = 0;
    float testNo = 0;
    float avg = 0;

    printf("Enter 0 when Completed. \n\n");

    do
    {
        printf("Test: %.0f  Average: %.2f \n", testNo, avg);
        printf("\nEnter the Score: ");
        scanf(" %f", &score);
        grade += score;
        testNo++;
        avg = grade / testNo;
    }
    while(score != 0);

    return 0;
}
