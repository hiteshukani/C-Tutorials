#include <stdio.h>
#include <stdlib.h>

void convertToDollars(float inr);

int main()
{
    float inrPrice1 = 67.25;
    float inrPrice2 = 100.00;
    float inrPrice3 = 250.00;


    convertToDollars(inrPrice1);
    convertToDollars(inrPrice2);
    convertToDollars(inrPrice3);
    convertToDollars(489.70);

    return 0;
}


void convertToDollars(float inr)
{
    float usd = inr / 67.25;
    printf("%.2f INR - %.2f USD\n", inr, usd);

    return;
}
