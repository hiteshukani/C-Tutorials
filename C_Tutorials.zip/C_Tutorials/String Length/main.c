#include <stdio.h>
#include <stdlib.h>

int main()
{
    char movie [20];
    char * pMovie = movie;              // Whenever you set pointer = array do not use &movie b'coz the name of your array is already a memory address

    fgets(pMovie, 20, stdin);           // fgets: to take input from keyboard and if user enter more than limit it just cutoff, stdin: is standard input basically from keyboard
    puts(pMovie);

    return 0;
}
