#include <stdio.h>
#include <stdlib.h>
#include "Hitesh.h"     // When you define a function name it in UPPERCASE
#define MYNAME "Hitesh Ukani"   // It replace MYNAME by Hitesh Ukani (Use of macros and replacing them)

int main()
{
    printf("My name is %s", MYNAME);
    int girlsAge = (AGE / 2) + 7;
    printf("%s can date girls of %d or older \n", MYNAME, girlsAge);
    return 0;
}
