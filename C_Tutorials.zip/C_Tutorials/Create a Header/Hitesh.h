#define MYNAME "Hitesh"
#define AGE 22
