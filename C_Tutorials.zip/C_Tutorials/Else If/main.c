#include <stdio.h>
#include <stdlib.h>

int main()
{
    float grade1, grade2, grade3;

    printf("Enter your 3 Grades: \n");
    scanf(" %f", &grade1);                              // Always use space in " %f" as a good programmer it depends on compiler
    scanf(" %f", &grade2);                              // %f for float and NOTE:'&' is used for every variable except Arrays
    scanf(" %f", &grade3);

    float avg = (grade1 + grade2 + grade3) / 3;
    printf("Average Grade: %.2f \n", avg);              // %.2f takes the value upto 2 decimal points

    if(avg >= 90)
    {
        printf("Grade: A");
    }
    else if(avg >=80)                                   // else if provides many choices
    {
        printf("Grade: B");
    }
    else if(avg >= 70)
    {
        printf("Grade: C");
    }
    else if(avg >= 60)
    {
        printf("Grade: D");
    }
    else
    {
        printf("You are Failed... \n");
    }
    return 0;
}
