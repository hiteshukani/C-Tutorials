#include <stdio.h>
#include <stdlib.h>

int main()
{
    int pageView = 0;
    pageView = pageView + 1;
    printf("Total Page View is: %d \n", pageView);

    pageView = pageView + 1;
    printf("Total Page View is: %d \n", pageView);

    pageView = pageView + 1;
    printf("Total Page View is: %d \n", pageView);

    float balance = 5000;                                       // *= is multiply and assign
    balance *= 1.2;
    printf("Balance at the end of 1st year is: %f \n", balance);

    balance *= 1.2;
    printf("Balance at the end of 2nd year is: %f \n", balance);

    balance *= 1.2;
    printf("Balance at the end of 3rd year is: %f \n", balance);

    return 0;
}
