#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE * fPointer;
    fPointer = fopen("info.txt", "w+");

    fputs("I ate 3 piece today", fPointer);

    fseek(fPointer, 8, SEEK_SET);                                 // fseek(Pointer name, poistion, SEEK_SET(starts from the begining)) is used to replace anything from text file
    fputs("apples on Saturday", fPointer);

    fseek(fPointer, -8, SEEK_END);                                // SEEK_END starts from end
    fputs("apples on SUNDAY", fPointer);

    fclose(fPointer);
    return 0;
}
