#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>                          // This .h file provides bunch of built in character
#include <string.h>                         // This .h file provides bunch of built in string functions
#include <math.h>

int main()
{
    char sim[100] = "Hey ";

    strcat(sim, "Hitesh... ");                 // strcat add the new string mentioned in function to original string Format: strcat(original string, "New String to add")
    strcat(sim, "You ");                       // NOTE: Don't exceed the string size
    strcat(sim, "are ");
    strcat(sim, "Sexy! ");
    printf("%s \n", sim);

    strcpy(sim, "Hitesh! You are Awesome! \n");// strcpy changes the original string by new string Format: strcpy(original string, "New String")
    printf("%s \n", sim);
    return 0;
}
