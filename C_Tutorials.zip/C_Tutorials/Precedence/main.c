#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 4 + 2 *6;
    printf("Result: %d \n", a);

    int b = (4 + 2) *6;             // Bracket () will overcome the rules of precedence i.e. priority of operations
    printf("Result: %d \n", b);
    return 0;
}
