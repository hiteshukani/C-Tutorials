#include <stdio.h>
#include <stdlib.h>

int main()
{
    float age1, age2, age3, average;
    age1 = age2 = 21;

    printf("Enter your age: \n");
    scanf("%f", &age3);

    average = (age1 + age2 + age3) / 3;
    printf("Average Age of Group is %f: \n", average);
    return 0;
}
