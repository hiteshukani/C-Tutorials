#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    char movie1[] = "Avengers!";
//  Never use array name on left side of assignment b'coz it assigns a new value to it and hence destroys your original array
//  movie1 = "Hey Now";
    char * movie2 = "Age of Ultron!";

    puts(movie2);

    movie2 = "New Movie Title?";

    puts(movie2);

    return 0;
}
