#include <stdio.h>
#include <stdlib.h>

int main()
{
    //char a;
    int i;

    //a = "Hitesh";
    i = sizeof("Hitesh");                           // Hitesh has 6 letters but there is a null character at the end of each String
    printf("Size of String Hitesh is %d \n", i);
    return 0;
}
