#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int i;
    int playerNo[5] = {10, 45, 7, 11, 99};
    int goals[5] = {48, 39, 42, 47, 23};
    int gamesPlayed[5] = {17, 20, 19, 20, 20};
    float ppg[5];
    float bestPPG = 0.0;
    int bestPlayer;

    for(i = 0; i < 5; i++)
    {
        ppg[i] = (float)goals[i] / (float)gamesPlayed[i];
        printf("Player: %d \t Goals: %d \t Games Played: %d \t Points Per Game: %.2f \n", playerNo[i], goals[i], gamesPlayed[i], ppg[i]);

        if(ppg[i] > bestPPG)
        {
            bestPPG = ppg[i];
            bestPlayer = playerNo[i];
        }
    }

    printf("\nThe Best Player is %d \n", bestPlayer);
    return 0;
}
