#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE * fPointer;
    fPointer = fopen("info.txt", "a");

    fprintf(fPointer, "\n - a rhyme by Hits");

    fclose(fPointer);

    return 0;
}
