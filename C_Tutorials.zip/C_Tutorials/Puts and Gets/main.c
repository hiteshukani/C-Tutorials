#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>                          // This .h file provides bunch of built in character
#include <string.h>                         // This .h file provides bunch of built in string functions
#include <math.h>

int main()
{
    char name[50];
    char food[25];
    char sentence[100];

    puts("What is your name? ");               // puts function works as printf and it already includes \n for new line
    gets(name);                                // gets function works as scanf and it doesn't require %d, %c, %f etc... It scanf whole string including space

    puts("What does you like to eat? ");
    gets(food);

    strcat(sentence, name);                    // Format: strcat(main string, string to be used)
    strcat(sentence, " loves to eat ");
    strcat(sentence, food);

    puts(sentence);
    return 0;
}
