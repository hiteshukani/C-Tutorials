#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE * fPointer;
    fPointer = fopen("info.txt", "r");

    char singleLine[100];

    while(!feof(fPointer))              // while(till end of the file(file name))
    {
        fgets(singleLine, 100, fPointer);
        puts(singleLine);
    }

    fclose(fPointer);

    return 0;
}
