#include <stdio.h>
#include <stdlib.h>

int main()
{
    char myName[10];
    char crush[10];
    int numberOfBabies;

    printf("What is your name? \n");
    scanf("%s", myName);                        // %s for String

    printf("Whom are you going to marry? \n");  // %s for String
    scanf("%s", crush);

    printf("How many babies you want? \n");     // %d for Numbers and NOTE:'&' is used for every variable except Arrays
    scanf("%d", &numberOfBabies);

    printf("%s loves %s and they will be having %d babies \n", crush, myName, numberOfBabies);

    return 0;
}
