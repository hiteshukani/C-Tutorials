#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("%s is my name\n", "Hitesh");    // %s is substituted by a string named "Hitesh"
    printf("%s is a %s person\n", "He", "Good");    // %s is substituted by string "He" and other %s by "Good"

    printf("I am %d year old\n", 22);         // %d is used for representing Integers like 1,2,3... NOTE: Numbers are not in "" only strings
    printf("My weight is %f kg\n", 67.467952314);     // For decimal pint %f is used and it will consider upto 6 decimal point by default
    printf("My weight is %.2f kg\n", 67.467952314);   // Print upto 2 decimal point
    printf("My weight is %.4f kg\n", 67.467952314);   // Print upto 4 decimal points
    return 0;
}
