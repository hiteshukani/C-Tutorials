#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 23;
    int b = 5;
    printf("%d \n", a/b);

    int c = 23;
    int d = 5;
    printf("%d \n", c%d);       // % is modulus operator which gives us remainder value NOTE: Only for Integers

    float e = 23;               // float is used to get values in decimal
    float f = 5;
    printf("%f \n", e/f);       // %f is used since we are using float

    return 0;
}
