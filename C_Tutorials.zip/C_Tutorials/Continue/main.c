#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int num = 1;

    do                              // <------------------------------------------------------------------------------------------------------------------
    {                               //                                                                                                                   |
        if(num == 3 || num == 5)    //                                                                                                                   |
        {                           //                                                                                                                   |
            num++;                  //                                                                                                                   |
            continue;               // if the condition of IF satisfies and Continue statement is executed it will go back to Do loop i.e. Initial loop---
        }
        printf("%d \n", num);
        num++;
    }
    while(num <= 10);

    return 0;
}
