#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
    int pizza = 21;
    int * pPizza = &pizza;

    printf("Address \t Name \t Value \n");
    printf("%p \t %s \t %d \n", pPizza, "pizza", pizza);
    printf("%p \t %s \t %p \n", &pPizza, "pPizza", pPizza);

    printf("\n*pPizza: %d \n", *pPizza);                    // Dereference Variable: *Variable_name

    *pPizza = 74;
    printf("\n*pPizza: %d \n", *pPizza);

    return 0;
}
