#include <stdint.h>

int main(void)
{
	int table[15][15];
	//table[0][0] = 1;
	int r, c;
	//c = 0;
	for(r = 0; r < 15; r++)
	{
		for(c = 0; c < 15; c++)
		{
			table[r][c] = (r + 1) * (c + 1);
		}	
	}
	
	// Sum of Diagonal \ from left top to right bottom
	int diaSum = 1;
	
	for(r = 0; r < 15; r++)
	{
		for(c = 0; c < 15; c++)
		{
			if(r = c)
			{
				diaSum += table[r][c];
			}
		}	
	}

	// Sum of diagonal / bottom left to top right
	int sumDiag = 0;
	r = 14;
	//for(r = 14; r > 0; r--)
	while(r > 0)
	{
		for(c = 0; c < 15; c++)
		{
			sumDiag += table[r][c];
			r--;
		}
	}	
	return 0;
	
}