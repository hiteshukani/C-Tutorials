#include<stdio.h>

int main(void)
{
float c, f;

f = 45;

c = (f-32)*5/9;

return 0;

}