#include<stdio.h>

int main(void)
{
float c, f;

c = 53;

f = c*9/5+32;

return 0;

}