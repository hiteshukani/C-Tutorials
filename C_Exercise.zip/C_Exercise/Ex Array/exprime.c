#include <stdint.h>

int main(void)
{
	int array[99];
	//array[0] = 2;
	int i;
	
	for(i = 0; i < 100; i++)
	{
		array[i] = i + 2;
		//array[i + 1] = array[i] + 1;
	}	
{
	int j = 0;
	
	while(j < 99)
	{
		i = 0;
		while(i < 99)
		{
			if(array[j] != 0) 
			{
				if((array[i + 1] != 0) && (i > j))
				{
					
					if(array[i+1] % array[j] == 0)
					{
						array[i + 1] = 0;
						i++;
					}
					else
					{
						i++;
					}
				}
				else
				{
					i++;
				}
			}
			else
			{
				j++;
			}
		}
		j++;
	}
	j++;
	
}	
	int noOfPrime;
		

	
	return 0;
}
